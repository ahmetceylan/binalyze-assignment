<template>
  <div>
    <h1>Gruplar</h1>
  </div>
</template>

<script setup lang="ts"></script>
