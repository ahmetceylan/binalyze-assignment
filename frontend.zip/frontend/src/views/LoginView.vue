<template>
  <div>
    <h1>Giriş Sayfası</h1>
  </div>
</template>

<script setup lang="ts"></script>
