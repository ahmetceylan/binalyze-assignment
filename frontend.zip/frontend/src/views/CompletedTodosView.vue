<template>
  <div>
    <h1>Tamamlanan Görevler</h1>
  </div>
</template>

<script setup lang="ts"></script>
