ASSIGNMENT
You will be expected to design a to-do app with both frontend and backend implementations. The app should have at least 4 screens which are: Login
Active To-Do List
Completed To-Do List
Group Management

In the login screen;
The user can login with its email and password
The user can create its account if it’s not already available
Basic authentication can be used but JWT is a plus.

In the active to-do list screen;
To-dos which are not completed yet must be shown.
To-dos can be updated or deleted
New to-dos can be created
To-dos can be marked as done.
To-dos must have priority, group and due-dates
To-dos can be filtered according to its group, priority and due-date
In the completed to-do list screen;
To-dos which are marked as done are shown
They can be deleted or marked as active.

In the group management screen,
Groups are shown. Every to-do must be belong to only one group. These groups are specific to the user. Each user has its own groups. The user can create, update or delete a group.
Group samples: Home, Work, Errands etc.

Some general requirements are as below:
We will prefer using Node and NestJS for backend and VueJS for frontend implementations, but it’s not a must. Feel free to use any language you like. Dockerize webapp and backend separately
Prepare a readme file to explain how the app will be installed and used Publish your code into a github repository and share the link with us Swagger use is a nice-to-have feature
JWT authentication and authorization mechanism is a nice-to-have feature Docker Compose use is a nice-to-have feature.
